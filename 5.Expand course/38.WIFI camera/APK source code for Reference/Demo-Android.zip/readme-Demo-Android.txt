工程中，工作区的几个ijkplayer-<cpu arch>工程为底层媒体库，被ijkplayer-java工程依赖，而
ijkplayer-java则被app中widget.media中的文件依赖，widget.media中的对外使用到的文件是IjkViewView.java，即预览中使用到的类。另外widget.media还使用到了一些资源，在colors.xml/strings.xml/dimens.xml文件中包含ijk的字段，如果需要移植到其他工程中，需要一同转移。

以下是各个组件依赖图：
   App(Preview)
       ↑
widget.media<IjkViewView.java>
       ↑
ijkplayer-java
       ↑
ijkplayer-<cpu arch>
最底下两层不需要更改，个别设置可能需要更改IjkViewView.java（例如一些初始化设置在createPlayer()方法中）。

AndroidManifest.xml中
    <uses-feature android:glEsVersion="0x00020000"/>
如果渲染使用OpenGL ES 2.0的话，需要在这里加上。目前因为Android不同机型的兼容性不是很好，所以暂时在预览中没有开启（现在使用RV32），但是可以配置使用。

其他一些设置，如NDK的abifilter等，在build.gradle(Module:app)中，根据需要更改。

Demo中已经包含断线重连，还有拍照、录像和向图传板发送数据等例子。

其他说明在Demo的注释中。