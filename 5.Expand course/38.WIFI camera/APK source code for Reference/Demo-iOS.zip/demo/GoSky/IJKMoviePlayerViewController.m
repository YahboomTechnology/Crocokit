/*
 * Copyright (C) 2013-2015 Bilibili
 * Copyright (C) 2013-2015 Zhang Rui <bbcallen@gmail.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#import "IJKMoviePlayerViewController.h"

// 重连等待间隔，单位s
#define RECONNECTION_INTERVAL   0.5

@implementation IJKVideoViewController
{
    int videoRotation;
}

- (void)dealloc
{
    [self removePlayerNotificationObservers];
    
    IJKFFMoviePlayerController *mpc = self.player;
    [mpc setDelegate:nil];
}

+ (void)presentFromViewController:(UIViewController *)viewController withTitle:(NSString *)title URL:(NSURL *)url completion:(void (^)())completion {
    [viewController presentViewController:[[IJKVideoViewController alloc] initWithURL:url] animated:YES completion:completion];
}

- (instancetype)initWithURL:(NSURL *)url {
    self = [self initWithNibName:@"IJKMoviePlayerViewController" bundle:nil];
    if (self) {
        self.url = url;
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#define EXPECTED_IJKPLAYER_VERSION (1 << 16) & 0xFF) | 
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.url = [NSURL URLWithString:@"rtsp://192.168.1.1:7070/webcam"];

    // Cannot place in installMovieNotificationObservers, if so, it takes no effect
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(willResignActive:)
                                                 name:UIApplicationWillResignActiveNotification
                                               object:_player];
    
    [self addTestingButtons];

//    [[UIApplication sharedApplication] setStatusBarHidden:YES];
//    [[UIApplication sharedApplication] setStatusBarOrientation:UIInterfaceOrientationLandscapeLeft animated:NO];
}

- (void)openVideo {
    IJKFFOptions *options = [IJKFFOptions optionsByDefault];
    // JPEG解析方式，默认使用填充方式（即网络数据包丢失，则用上一帧数据补上），可以改为DROP（丢失数据包则丢掉整帧，网络不好不要使用），ORIGIN（原始方式，不要使用）
    [options setPlayerOptionIntValue:RtpJpegParsePacketMethodDrop forKey:@"rtp-jpeg-parse-packet-method"];
    // 读网络包超时时间
    [options setPlayerOptionIntValue:2500 * 1000 forKey:@"readtimeout"];

    IJKFFMoviePlayerController *moviePlayerController = [[IJKFFMoviePlayerController alloc] initWithContentURL:self.url withOptions:options];
    moviePlayerController.delegate = self;

    self.player = moviePlayerController;
    self.player.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    self.player.view.frame = self.view.bounds;
    // 拉伸方式，根据需要选择等比例拉伸或者全屏拉伸等
    self.player.scalingMode = IJKMPMovieScalingModeFill;
    self.player.shouldAutoplay = YES;

    self.view.autoresizesSubviews = YES;
//    [self.view addSubview:self.player.view];
    [self.view insertSubview:self.player.view atIndex:0];
    
    videoRotation = 0;
    
    // put log setting here to make it fresh
#ifdef DEBUG
    [IJKFFMoviePlayerController setLogReport:YES];
    [IJKFFMoviePlayerController setLogLevel:k_IJK_LOG_INFO];
#else
    [IJKFFMoviePlayerController setLogReport:NO];
    [IJKFFMoviePlayerController setLogLevel:k_IJK_LOG_SILENT];
#endif
    
    // [IJKFFMoviePlayerController checkIfFFmpegVersionMatch:YES];
    // [IJKFFMoviePlayerController checkIfPlayerVersionMatch:YES major:1 minor:0 micro:0];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self openVideo];
    [self installMovieNotificationObservers];
    [self.player prepareToPlay];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // 禁用自动锁屏
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self.player stopRecordVideo];
    
    [self.player shutdown];
    [self.player.view removeFromSuperview];
    [self removeMovieNotificationObservers];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    // 恢复自动锁屏
    [[UIApplication sharedApplication] setIdleTimerDisabled:NO];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return UIInterfaceOrientationIsLandscape(toInterfaceOrientation);
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)isVisible
{
    return [self isViewLoaded] && self.view.window;
}

#pragma mark Handle Notification

- (void)loadStateDidChange:(NSNotification*)notification
{
    //    MPMovieLoadStateUnknown        = 0,
    //    MPMovieLoadStatePlayable       = 1 << 0,
    //    MPMovieLoadStatePlaythroughOK  = 1 << 1, // Playback will be automatically started in this state when shouldAutoplay is YES
    //    MPMovieLoadStateStalled        = 1 << 2, // Playback will be automatically paused in this state, if started

    IJKMPMovieLoadState loadState = _player.loadState;

    if ((loadState & IJKMPMovieLoadStatePlaythroughOK) != 0) {
        NSLog(@"loadStateDidChange: IJKMPMovieLoadStatePlaythroughOK: %d\n", (int)loadState);
    } else if ((loadState & IJKMPMovieLoadStateStalled) != 0) {
        NSLog(@"loadStateDidChange: IJKMPMovieLoadStateStalled: %d\n", (int)loadState);
    } else {
        NSLog(@"loadStateDidChange: ???: %d\n", (int)loadState);
    }
}

// 结束播放通知
- (void)moviePlayBackDidFinish:(NSNotification*)notification
{
    //    MPMovieFinishReasonPlaybackEnded,
    //    MPMovieFinishReasonPlaybackError,
    //    MPMovieFinishReasonUserExited
    int reason = [[[notification userInfo] valueForKey:IJKMPMoviePlayerPlaybackDidFinishReasonUserInfoKey] intValue];

    switch (reason)
    {
        case IJKMPMovieFinishReasonPlaybackEnded:
            NSLog(@"playbackStateDidChange: IJKMPMovieFinishReasonPlaybackEnded: %d\n", reason);
            break;

        case IJKMPMovieFinishReasonUserExited:
            NSLog(@"playbackStateDidChange: IJKMPMovieFinishReasonUserExited: %d\n", reason);
            break;

        case IJKMPMovieFinishReasonPlaybackError:
            NSLog(@"playbackStateDidChange: IJKMPMovieFinishReasonPlaybackError: %d\n", reason);
            // Player stopped but have not release resources
            // So, we must shut it down manually
            // And wait for delegate method
            [self.player shutdown];
            [self.player.view removeFromSuperview];
            break;

        default:
            NSLog(@"playbackPlayBackDidFinish: ???: %d\n", reason);
            break;
    }
}

// 准备开始预览通知
- (void)mediaIsPreparedToPlayDidChange:(NSNotification*)notification
{
    NSLog(@"mediaIsPreparedToPlayDidChange\n");
}

- (void)moviePlayBackStateDidChange:(NSNotification*)notification
{
    //    MPMoviePlaybackStateStopped,
    //    MPMoviePlaybackStatePlaying,
    //    MPMoviePlaybackStatePaused,
    //    MPMoviePlaybackStateInterrupted,
    //    MPMoviePlaybackStateSeekingForward,
    //    MPMoviePlaybackStateSeekingBackward

    switch (_player.playbackState)
    {
        case IJKMPMoviePlaybackStateStopped: {
            NSLog(@"IJKMPMoviePlayBackStateDidChange %d: stoped", (int)_player.playbackState);
            break;
        }
        case IJKMPMoviePlaybackStatePlaying: {
            NSLog(@"IJKMPMoviePlayBackStateDidChange %d: playing", (int)_player.playbackState);
            break;
        }
        case IJKMPMoviePlaybackStatePaused: {
            NSLog(@"IJKMPMoviePlayBackStateDidChange %d: paused", (int)_player.playbackState);
            break;
        }
        case IJKMPMoviePlaybackStateInterrupted: {
            NSLog(@"IJKMPMoviePlayBackStateDidChange %d: interrupted", (int)_player.playbackState);
            break;
        }
        case IJKMPMoviePlaybackStateSeekingForward:
        case IJKMPMoviePlaybackStateSeekingBackward: {
            NSLog(@"IJKMPMoviePlayBackStateDidChange %d: seeking", (int)_player.playbackState);
            break;
        }
        default: {
            NSLog(@"IJKMPMoviePlayBackStateDidChange %d: unknown", (int)_player.playbackState);
            break;
        }
    }
}

#pragma mark IJKMoviePlayerControllerDelegate

- (void)moviePlayerDidShutdown:(IJKFFMoviePlayerController *)player
{
    IJKFFMoviePlayerController *mpc = self.player;
    [mpc setDelegate:nil];
    
    [self.player.view removeFromSuperview];
    [self removeMovieNotificationObservers];
    [self performSelector:@selector(doReconnect) withObject:self afterDelay:RECONNECTION_INTERVAL];
}

- (void)doReconnect
{
    if ([self isVisible]) {
        NSLog(@"doReconnect");
        [self openVideo];
        [self installMovieNotificationObservers];
        [self.player prepareToPlay];
    }
}

- (void)willResignActive:(NSNotification *)notification
{
    NSLog(@"ControlPanelViewController:willResignActive");
    
    [self.player stopRecordVideo];
}

// 收到图传板数据回调
/**
 * 从固件接收数据，使用RTCP通道，所以如果要使用，必须要加入区分原RTCP数据的逻辑（使用独特的包结构或者校验即可）
 */
- (void)player:(IJKFFMoviePlayerController *)player didReceiveRtcpSrData:(NSData *)data
{
    // 因为数据通道是和RTCP共用，所以回传数据需要和RTCP的Sender Report区分开，需要加上自己的标志区分
    // RTCP默认每5秒发送一次Sender Report
    // 以后会封装起来，直接发送和接收数据
    NSLog(@"didReceiveRtcpSrData: %@", data);
}

// 拍照回调
// resultCode，<0 发生错误，=0 拍下一张照片，=1，完成拍照
- (void)playerDidTakePicture:(IJKFFMoviePlayerController *)player resultCode:(int)resultCode fileName:(NSString *)fileName
{
    if (resultCode == 1) {
        // 拍照结束
        [self showInfo:@"拍照结束"];
    }
    else if (resultCode == 0) {
        // 成功保存一张照片
        [self showInfo:[NSString stringWithFormat:@"成功保存照片：%@", fileName]];
    }
    else if (resultCode < 0) {
        // 拍照失败
        [self showInfo:@"拍照失败"];
    }
}

// 录像回调
// resultCode，<0 发生错误，=0开始录像，否则就是成功保存录像
- (void)playerDidRecordVideo:(IJKFFMoviePlayerController *)player resultCode:(int)resultCode fileName:(NSString *)fileName
{
    if (resultCode < 0) {
        // 录像失败
        [self showInfo:@"录像失败"];
    }
    else if (resultCode == 0) {
        // 录像开始
        [self showInfo:@"录像开始，再次按下停止录像"];
    }
    else {
        // 录像结束
        [self showInfo:[NSString stringWithFormat:@"成功保存录像：%@", fileName]];
    }
}

#pragma mark Install Movie Notifications

/* Register observers for the various movie object notifications. */
-(void)installMovieNotificationObservers
{
	[[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(loadStateDidChange:)
                                                 name:IJKMPMoviePlayerLoadStateDidChangeNotification
                                               object:_player];

	[[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackDidFinish:)
                                                 name:IJKMPMoviePlayerPlaybackDidFinishNotification
                                               object:_player];

	[[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(mediaIsPreparedToPlayDidChange:)
                                                 name:IJKMPMediaPlaybackIsPreparedToPlayDidChangeNotification
                                               object:_player];

	[[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayBackStateDidChange:)
                                                 name:IJKMPMoviePlayerPlaybackStateDidChangeNotification
                                               object:_player];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlayerDidShutdown:)
                                                 name:IJKMPMoviePlayerDidShutdownNotification
                                               object:_player];
}

#pragma mark Remove Movie Notification Handlers

/* Remove the movie notification observers from the movie object. */
-(void)removeMovieNotificationObservers
{
    NSLog(@"removeMovieNotificationObservers");
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMoviePlayerLoadStateDidChangeNotification object:_player];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMoviePlayerPlaybackDidFinishNotification object:_player];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMediaPlaybackIsPreparedToPlayDidChangeNotification object:_player];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMoviePlayerPlaybackStateDidChangeNotification object:_player];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:IJKMPMoviePlayerDidShutdownNotification object:_player];
}

-(void)removePlayerNotificationObservers
{
    NSLog(@"removePlayerNotificationObservers");
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIApplicationWillResignActiveNotification object:_player];
}

#pragma mark -

inline static IJKFFMoviePlayerController *ffplayerInstance(id<IJKMediaPlayback> player)
{
    return player;
}

inline static VideoRecordingStatus ffplayerVideoRecordingStatus(IJKFFMoviePlayerController *ffplayer)
{
    return ffplayer.videoRecordingStatus;
}

#pragma mark - testing

/**
 * 执行拍照
 */
- (void)doTakePicture:(int)number
{
    NSString *dirPath = [self mediaDirPath];
    NSString *fileName = [self mediaFileName];

    // 拍照参数说明
    // 1、目录路径，目录需要先创建，否则返回错误
    // 2、文件名，不需要指定扩展名
    // 3和4、保存图像的宽高，如果都是-1（不允许只有一个-1），则保存原图像大小，如果是其他，则拉伸为设定值
    // 5、连续拍照数量，连续拍照，中间不设间隔
    [self.player takePictureAtPath:dirPath withFileName:fileName width:-1 height:-1 number:number];
}

- (void)takePicture
{
    [self doTakePicture:1];
}

/**
 * 录像，目前固定保存为MOV
 * 目前MJPEG格式为YUV420P，部分手机的默认播放器不支持，只支持YUV422P，不支持直接播放和使用什么容器（比如AVI、MP4）无关
 * 以后会加入录制时转码功能，但是使用这个功能在低端手机上可能会造成卡顿，根据实际需要选择使用
 */
- (void)doRecordVideo
{
    NSString *dirPath = [self mediaDirPath];
    NSString *fileName = [[self mediaFileName] stringByAppendingPathExtension:@"mov"];
    // 录像参数说明
    // 1、目录路径，目录需要先创建，否则返回错误
    // 2、文件名，目前固定给".mov"，下一个版本将自动指定扩展名，届时会有说明
    // 3和4、录像的宽高，目前不使用，保留
    [self.player startRecordVideoAtPath:dirPath withFileName:fileName width:-1 height:-1];
}

- (void)recordVideo
{
    IJKFFMoviePlayerController *ffplayer = ffplayerInstance(self.player);
    VideoRecordingStatus status = ffplayerVideoRecordingStatus(ffplayer);
    
    // take recording action and wait for delegate method
    // if idle, start recording
    if (status == VideoRecordingStatusIdle) {
        [self doRecordVideo];
    }
    // if recording, stop it
    else if (status == VideoRecordingStatusRecording) {
        [self.player stopRecordVideo];
    }
    // if stopping, do nothing
    else {
        NSLog(@"Recording video: Do nothing");
    }
}

/**
 * 发送飞控数据
 * 因为数据通道是和RTCP共用，所以数据需要和RTCP的Receive Report区分开，需要加上自己的标志区分
 * 以后会封装起来，直接发送和接收数据
 */
- (void)doSendData
{
    Byte controlBytes[8];
    
    controlBytes[0] = 0x66;
    controlBytes[1] = 0x80;
    controlBytes[2] = 0x80;
    controlBytes[3] = 0x80;
    controlBytes[4] = 0x80;
    controlBytes[5] = 0x00;
    controlBytes[6] = 0x00;
    controlBytes[7] = 0x99;
    
    NSData *controlData = [NSData dataWithBytes:controlBytes length:8];
    [self.player sendRtcpRrData:controlData];
}

/**
 * 设置VR模式（左右分屏显示）
 */
- (void)doSetVrMode
{
    [self.player setVrMode:!self.player.isVrMode];
}

/**
 * 软件旋转屏幕，顺时针旋转（非Sensor旋转，图传传过来的图旋转角度不变，改变的是渲染的图像角度，不影响拍照和录像）
 */
- (void)doSetVideoRotation
{
    // 以90度翻转
//    IJKFFMoviePlayerController *ffplayer = ffplayerInstance(self.player);
//    videoRotation += 90;
//    [ffplayer setVideoRotation:videoRotation];  // 拉伸模式（IJKMPMovieScalingModeFill）下不可用，看情形使用不同的翻转
    
    // 以180度翻转
    [self.player setRotation180:!self.player.isRotation180];
}

- (void)addTestingButtons
{
    UIButton *takePictureButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [takePictureButton setTitle:@"--拍照--" forState:UIControlStateNormal];
    [takePictureButton sizeToFit];
    [takePictureButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:takePictureButton];
    
    UIButton *recordVideoButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [recordVideoButton setTitle:@"--录像--" forState:UIControlStateNormal];
    [recordVideoButton sizeToFit];
    [recordVideoButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:recordVideoButton];
    
    UIButton *sendDataButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [sendDataButton setTitle:@"发送数据" forState:UIControlStateNormal];
    [sendDataButton sizeToFit];
    [sendDataButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:sendDataButton];
    
    UIButton *setVrModeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [setVrModeButton setTitle:@"VR模式" forState:UIControlStateNormal];
    [setVrModeButton sizeToFit];
    [setVrModeButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:setVrModeButton];
    
    UIButton *setVideoRotationButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [setVideoRotationButton setTitle:@"图像翻转90°(软件)" forState:UIControlStateNormal];
    [setVideoRotationButton sizeToFit];
    [setVideoRotationButton setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:setVideoRotationButton];
    
    // Action
    [takePictureButton addTarget:self action:@selector(takePicture) forControlEvents:UIControlEventTouchUpInside];
    [recordVideoButton addTarget:self action:@selector(recordVideo) forControlEvents:UIControlEventTouchUpInside];
    [sendDataButton addTarget:self action:@selector(doSendData) forControlEvents:UIControlEventTouchUpInside];
    [setVrModeButton addTarget:self action:@selector(doSetVrMode) forControlEvents:UIControlEventTouchUpInside];
    [setVideoRotationButton addTarget:self action:@selector(doSetVideoRotation) forControlEvents:UIControlEventTouchUpInside];
    
    // CornerRadius
    [takePictureButton.layer setCornerRadius:4];
    [recordVideoButton.layer setCornerRadius:4];
    [sendDataButton.layer setCornerRadius:4];
    [setVrModeButton.layer setCornerRadius:4];
    [setVideoRotationButton.layer setCornerRadius:4];
    
    // Color
    [takePictureButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [takePictureButton setTitleColor:[UIColor magentaColor] forState:UIControlStateHighlighted];
    [takePictureButton setBackgroundColor:[UIColor lightGrayColor]];
    
    [recordVideoButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [recordVideoButton setTitleColor:[UIColor magentaColor] forState:UIControlStateHighlighted];
    [recordVideoButton setBackgroundColor:[UIColor lightGrayColor]];
    
    [sendDataButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [sendDataButton setTitleColor:[UIColor magentaColor] forState:UIControlStateHighlighted];
    [sendDataButton setBackgroundColor:[UIColor lightGrayColor]];
    
    [setVrModeButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [setVrModeButton setTitleColor:[UIColor magentaColor] forState:UIControlStateHighlighted];
    [setVrModeButton setBackgroundColor:[UIColor lightGrayColor]];
    
    [setVideoRotationButton setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [setVideoRotationButton setTitleColor:[UIColor magentaColor] forState:UIControlStateHighlighted];
    [setVideoRotationButton setBackgroundColor:[UIColor lightGrayColor]];
    
    
    // H
    NSDictionary *views = NSDictionaryOfVariableBindings(takePictureButton, recordVideoButton, sendDataButton, setVrModeButton, setVideoRotationButton);
    NSDictionary *metrics = @{ @"leading": @20, @"margin": @20 };
    
    NSArray *constraints = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-leading-[takePictureButton]-margin-[recordVideoButton]-margin-[sendDataButton]-margin-[setVrModeButton]-margin-[setVideoRotationButton]" options:NSLayoutFormatAlignAllCenterY metrics:metrics views:views];
    
    [self.view addConstraints:constraints];
    
    // V
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:takePictureButton
                                                          attribute:NSLayoutAttributeBottom
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeBottom
                                                         multiplier:1.0
                                                           constant:-8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:recordVideoButton
                                                          attribute:NSLayoutAttributeBottom
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeBottom
                                                         multiplier:1.0
                                                           constant:-8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:sendDataButton
                                                          attribute:NSLayoutAttributeBottom
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeBottom
                                                         multiplier:1.0
                                                           constant:-8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:setVrModeButton
                                                          attribute:NSLayoutAttributeBottom
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeBottom
                                                         multiplier:1.0
                                                           constant:-8]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:setVideoRotationButton
                                                          attribute:NSLayoutAttributeBottom
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeBottom
                                                         multiplier:1.0
                                                           constant:-8]];
}

- (void)showInfo:(NSString *)infoText
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil
                                                        message:infoText
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
    [alertView show];
}

/**
 *  返回Document路径
 *
 *  @return Document路径
 */
- (NSString *)documentPath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return [paths firstObject];
}

/**
 *  返回以当天日期作为路径的目录名
 *  自动创建目录，成功返回目录名，不成功返回nil
 */
- (NSString *)mediaDirPath
{
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyyMMdd"];
    NSString *dirName = [dateFormatter stringFromDate:date];
    NSString *dirPath = [[self documentPath] stringByAppendingPathComponent:dirName];
    
    if ([[NSFileManager defaultManager] createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil error:nil])
        return dirPath;
    
    return nil;
}

/**
 *  返回以时间作为路径的文件名
 */
- (NSString *)mediaFileName
{
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"HHmmssS"];
    NSString *fileName = [dateFormatter stringFromDate:date];
    
    return fileName;
}

@end
