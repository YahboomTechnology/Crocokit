//
//  AppDelegate.h
//  GoSky
//
//  Created by buildwin on 2017/8/11.
//  Copyright © 2017年 Buildwin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

